echo {0..9999} | xargs -n1 -P3 sh single_command.sh
